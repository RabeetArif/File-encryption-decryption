
int Encryption(char * FILENAME, char * NEW_FILENAME);