#ifndef ENCRYPTION_HEADER_FILE
#define ENCRYPTION_HEADER_FILE

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>

#define ENCRYPTION_FORMULA  (int) Byte + 25


#endif
