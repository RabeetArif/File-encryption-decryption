#ifndef UTIL_HEADER_FILE
#define UTIL_HEADER_FILE

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>


#include"./Login/Login_header.h"
#include"./Registration/Registration_header.h"
#include"./Encryption/encryption_header.h"
#include"./Decryption/decryption_header.h"
#include"./File_Status/status_header.h"


#endif