 
 int Decryption(char * FILENAME, char * NEW_FILENAME);