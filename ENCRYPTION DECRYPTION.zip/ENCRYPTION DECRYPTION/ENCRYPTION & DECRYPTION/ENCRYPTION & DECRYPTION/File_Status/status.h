

void print_File_Status(struct stat stats);